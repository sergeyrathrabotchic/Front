function img(img) {
    var img = document.querySelector(img);
    img.style.display = "block";
    //alert(img.style.display);
    /*var text = document.querySelector(text);
    text.style.display = "none";*/
}